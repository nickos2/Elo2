-- Loty (baga\u017c podr\u0119czny: limit wagi, suma wymiar\u00f3w X+Y+Z, stawka za kg nadbaga\u017cu, kara za gabaryty)
INSERT INTO lot (trasa, limit_wagi_kg, limit_suma_wymiarow_cm, stawka_za_kg_nadbagazu, oplata_za_przekroczone_gabaryty)
VALUES ('WAW-LHR', 8, 115, 50.00, 150.00);
INSERT INTO lot (trasa, limit_wagi_kg, limit_suma_wymiarow_cm, stawka_za_kg_nadbagazu, oplata_za_przekroczone_gabaryty)
VALUES ('KRK-FRA', 10, 118, 40.00, 120.00);
INSERT INTO lot (trasa, limit_wagi_kg, limit_suma_wymiarow_cm, stawka_za_kg_nadbagazu, oplata_za_przekroczone_gabaryty)
VALUES ('GDN-BER', 8, 115, 45.00, 130.00);
