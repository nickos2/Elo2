# Baga\u017c lotniczy - kalkulator dop\u0142at za nadbaga\u017c

Samodzielny projekt Spring Boot 3 / Java 17 obs\u0142uguj\u0105cy odpraw\u0119 online:
walidacj\u0119 gabaryt\u00f3w baga\u017cu podr\u0119cznego oraz naliczanie dop\u0142aty za nadbaga\u017c.

## Uruchomienie

Wymagania: JDK 17+, Maven 3.9+ (dost\u0119p do Maven Central).

```bash
mvn spring-boot:run
```

- Swagger UI: `http://localhost:8080/swagger-ui.html`
- Konsola H2: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:bagaz`, user `sa`, puste has\u0142o)
- Prosty UI odprawy: `http://localhost:8080/checkin.html`

Testy jednostkowe:

```bash
mvn test
```

## Dane startowe (data.sql)

| id | trasa | limit wagi | limit sumy wymiar\u00f3w | stawka/kg | kara za gabaryty |
|---|---|---|---|---|---|
| 1 | WAW-LHR | 8 kg | 115 cm | 50 z\u0142 | 150 z\u0142 |
| 2 | KRK-FRA | 10 kg | 118 cm | 40 z\u0142 | 120 z\u0142 |
| 3 | GDN-BER | 8 kg | 115 cm | 45 z\u0142 | 130 z\u0142 |

## Bezpiecze\u0144stwo

Klient nie loguje si\u0119 tradycyjnie - jego to\u017csamo\u015bci\u0105 jest numer rezerwacji, przekazywany
w nag\u0142\u00f3wku `X-Numer-Rezerwacji`. Mo\u017ce walidowa\u0107 wy\u0142\u0105cznie w\u0142asny baga\u017c (numer w nag\u0142\u00f3wku
musi zgadza\u0107 si\u0119 z numerem w \u017c\u0105daniu, w przeciwnym razie `403`).

Pracownik lotniska loguje si\u0119 przez HTTP Basic: `pracownik` / `pracownik123`, rola
`PRACOWNIK_LOTNISKA` - widzi wszystkie baga\u017ce dla danego lotu (`GET /api/bagaz/lot/{lotId}`),
niezale\u017cnie od numeru rezerwacji.

## Endpointy REST

| Metoda | Endpoint | Opis | Dost\u0119p |
|---|---|---|---|
| POST | `/api/bagaz/waliduj` | Waliduje gabaryty i zwraca sum\u0119 dop\u0142aty | klient (w\u0142asna rezerwacja) / pracownik |
| GET | `/api/bagaz/lot/{lotId}` | Lista baga\u017cy dla lotu | pracownik lotniska |

Przyk\u0142ad:

```bash
curl -X POST http://localhost:8080/api/bagaz/waliduj \
  -H "Content-Type: application/json" \
  -H "X-Numer-Rezerwacji: REZ-123" \
  -d '{"numerRezerwacji":"REZ-123","lotId":1,"wagaKg":10.5,"wymiarXCm":55,"wymiarYCm":40,"wymiarZCm":20}'
```

Odpowied\u017a zawiera m.in. `mieisciSieWGabarytach`, `nadwagaKg`, `doplataZaNadwage`,
`oplataZaGabaryty` oraz `sumaDoZaplaty`.

## Algorytm (`BagazService.oblicz`)

1. Suma wymiar\u00f3w X+Y+Z jest por\u00f3wnywana z limitem lotu - je\u015bli przekroczona, doliczana jest
   op\u0142ata rycza\u0142towa za gabaryty.
2. Ka\u017cdy kilogram wagi powy\u017cej limitu bazowego lotu mno\u017cony jest przez stawk\u0119 lotu za kg
   nadbaga\u017cu.
3. Suma do zap\u0142aty = dop\u0142ata za nadwag\u0119 + (ewentualna) op\u0142ata za gabaryty.

## Testy

`BagazServiceTest` sprawdza: baga\u017c w granicach limit\u00f3w (brak dop\u0142aty), nadwag\u0119 (dop\u0142ata
proporcjonalna do kg), przekroczone gabaryty (kara rycza\u0142towa), r\u00f3wnoczesne przekroczenie
wagi i gabaryt\u00f3w (suma obu op\u0142at) oraz przypadek graniczny (suma wymiar\u00f3w r\u00f3wna limitowi).
