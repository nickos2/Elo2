-- Miejsca parkingowe
INSERT INTO miejsce_parkingowe (strefa) VALUES ('A');
INSERT INTO miejsce_parkingowe (strefa) VALUES ('B');
INSERT INTO miejsce_parkingowe (strefa) VALUES ('VIP');
