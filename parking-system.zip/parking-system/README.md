# Parking - kalkulator op\u0142at za post\u00f3j

Samodzielny projekt Spring Boot 3 / Java 17 do rozpoczynania/ko\u0144czenia post\u0142oj\u00f3w
oraz naliczania op\u0142aty za czas parkowania.

## Uruchomienie

Wymagania: JDK 17+, Maven 3.9+ (dost\u0119p do Maven Central).

```bash
mvn spring-boot:run
```

- Swagger UI: `http://localhost:8080/swagger-ui.html`
- Konsola H2: `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:parking`, user `sa`, puste has\u0142o)
- Prosty UI: `http://localhost:8080/parking.html`

Testy jednostkowe:

```bash
mvn test
```

## Dane startowe (data.sql)

Miejsca parkingowe w strefach: A, B, VIP.

## Bezpiecze\u0144stwo

Klient nie loguje si\u0119 tradycyjnie - jego to\u017csamo\u015bci\u0105 jest numer rejestracyjny pojazdu,
przekazywany w nag\u0142\u00f3wku `X-Numer-Rejestracyjny`. Mo\u017ce obs\u0142ugiwa\u0107 wy\u0142\u0105cznie w\u0142asny pojazd
(numer w nag\u0142\u00f3wku musi zgadza\u0107 si\u0119 z numerem w \u017c\u0105daniu, w przeciwnym razie `403`).

Kontroler loguje si\u0119 przez HTTP Basic: `kontroler` / `kontroler123`, rola `KONTROLER` -
widzi list\u0119 wszystkich aktywnych post\u0142oj\u00f3w (`GET /api/parking/aktywne`).

## Endpointy REST

| Metoda | Endpoint | Opis | Dost\u0119p |
|---|---|---|---|
| POST | `/api/parking/rozpocznij` | Rozpoczyna post\u00f3j | klient (w\u0142asny pojazd) |
| GET | `/api/parking/{numerRejestracyjny}/kwota` | Bie\u017c\u0105ca kwota do zap\u0142aty | klient (w\u0142asny pojazd) / kontroler |
| POST | `/api/parking/{numerRejestracyjny}/zakoncz` | Ko\u0144czy post\u00f3j i nalicza op\u0142at\u0119 | klient (w\u0142asny pojazd) |
| GET | `/api/parking/aktywne` | Lista wszystkich aktywnych post\u0142oj\u00f3w | kontroler |

Przyk\u0142ad:

```bash
curl -X POST http://localhost:8080/api/parking/rozpocznij \
  -H "Content-Type: application/json" \
  -H "X-Numer-Rejestracyjny: WA12345" \
  -d '{"numerRejestracyjny":"WA12345"}'

curl http://localhost:8080/api/parking/WA12345/kwota -H "X-Numer-Rejestracyjny: WA12345"

curl -X POST http://localhost:8080/api/parking/WA12345/zakoncz -H "X-Numer-Rejestracyjny: WA12345"
```

## Algorytm (`PostojService.obliczOplate`)

- pierwsza rozpocz\u0119ta godzina: 5 z\u0142,
- ka\u017cda kolejna rozpocz\u0119ta godzina: 4 z\u0142,
- je\u015bli post\u00f3j rozpocz\u0105\u0142 si\u0119 w weekend (sobota lub niedziela) - ca\u0142a kwota jest o po\u0142ow\u0119
  ta\u0144sza (uproszczenie: liczy si\u0119 dzie\u0144 rozpocz\u0119cia post\u0142oju, bez dzielenia op\u0142aty
  godzina-po-godzinie mi\u0119dzy dni robocze a weekend).

## Testy

`PostojServiceTest` sprawdza: post\u00f3j kr\u00f3tszy ni\u017c godzina (1 stawka), post\u00f3j wielogodzinny
(pierwsza godzina + kolejne rozpocz\u0119te), zni\u017ck\u0119 w sobot\u0119 i niedziel\u0119, post\u00f3j zerowej
d\u0142ugo\u015bci (brak op\u0142aty), b\u0142\u0119dny zakres czasu (wyj\u0105tek) oraz zaokr\u0105glanie rozpocz\u0119tych godzin.
