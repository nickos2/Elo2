# Baga\u017c lotniczy (dop\u0142aty) + Parking (kalkulator op\u0142at)

Projekt w Spring Boot 3 / Java 17, zawieraj\u0105cy dwa niezale\u017cne modu\u0142y opisane w wymaganiach:

1. **Baga\u017c** - walidacja gabaryt\u00f3w baga\u017cu podr\u0119cznego i naliczanie dop\u0142aty za nadbaga\u017c.
2. **Parking** - naliczanie op\u0142aty za post\u00f3j (stawki godzinowe + zni\u017cka weekendowa).

## Uruchomienie

Wymagania: JDK 17+, Maven 3.9+ (dost\u0119p do Maven Central do pobrania zale\u017cno\u015bci).

```bash
mvn spring-boot:run
```

Aplikacja startuje na `http://localhost:8080`.

- Swagger UI: `http://localhost:8080/swagger-ui.html`
- Konsola H2 (baza w pami\u0119ci): `http://localhost:8080/h2-console` (JDBC URL: `jdbc:h2:mem:bagazparking`, user `sa`, puste has\u0142o)
- Prosty UI odprawy baga\u017cowej: `http://localhost:8080/checkin.html`
- Prosty UI parkingu: `http://localhost:8080/parking.html`

Testy jednostkowe:

```bash
mvn test
```

## Dane startowe (data.sql)

- Lot id=1: `WAW-LHR`, limit 8 kg / 115 cm sumy wymiar\u00f3w, 50 z\u0142/kg nadbaga\u017cu, 150 z\u0142 kary za gabaryty.
- Lot id=2: `KRK-FRA`, limit 10 kg / 118 cm, 40 z\u0142/kg, 120 z\u0142 kary.
- Miejsca parkingowe: strefy A, B, VIP.

## Bezpiecze\u0144stwo

Klient nie loguje si\u0119 tradycyjnie - jego to\u017csamo\u015bci\u0105 jest numer rezerwacji / numer rejestracyjny,
przekazywany w nag\u0142\u00f3wku ka\u017cdego \u017c\u0105dania:

- `X-Numer-Rezerwacji: <numer>` - modu\u0142 baga\u017cowy, klient widzi/waliduje wy\u0142\u0105cznie w\u0142asny baga\u017c
  (numer w nag\u0142\u00f3wku musi zgadza\u0107 si\u0119 z numerem w \u017c\u0105daniu, inaczej `403`).
- `X-Numer-Rejestracyjny: <numer>` - modu\u0142 parkingowy, klient widzi/obs\u0142uguje wy\u0142\u0105cznie w\u0142asny pojazd.

Personel loguje si\u0119 przez HTTP Basic (przegl\u0105darka poprosi o dane, lub nag\u0142\u00f3wek `Authorization`):

- `pracownik` / `pracownik123` - rola `PRACOWNIK_LOTNISKA`, widzi wszystkie baga\u017ce dla danego lotu
  (`GET /api/bagaz/lot/{lotId}`).
- `kontroler` / `kontroler123` - rola `KONTROLER`, widzi list\u0119 wszystkich aktywnych post\u0142oj\u00f3w
  (`GET /api/parking/aktywne`).

## G\u0142\u00f3wne endpointy REST

### Baga\u017c

| Metoda | Endpoint | Opis | Dost\u0119p |
|---|---|---|---|
| POST | `/api/bagaz/waliduj` | Waliduje gabaryty i zwraca sum\u0119 dop\u0142aty | klient (w\u0142asna rezerwacja) / pracownik |
| GET | `/api/bagaz/lot/{lotId}` | Lista baga\u017cy dla lotu | pracownik lotniska |

Przyk\u0142adowe \u017c\u0105danie:

```bash
curl -X POST http://localhost:8080/api/bagaz/waliduj \
  -H "Content-Type: application/json" \
  -H "X-Numer-Rezerwacji: REZ-123" \
  -d '{"numerRezerwacji":"REZ-123","lotId":1,"wagaKg":10.5,"wymiarXCm":55,"wymiarYCm":40,"wymiarZCm":20}'
```

### Parking

| Metoda | Endpoint | Opis | Dost\u0119p |
|---|---|---|---|
| POST | `/api/parking/rozpocznij` | Rozpoczyna post\u00f3j | klient (w\u0142asny pojazd) |
| GET | `/api/parking/{numerRejestracyjny}/kwota` | Bie\u017c\u0105ca kwota do zap\u0142aty | klient (w\u0142asny pojazd) / kontroler |
| POST | `/api/parking/{numerRejestracyjny}/zakoncz` | Ko\u0144czy post\u00f3j i nalicza op\u0142at\u0119 | klient (w\u0142asny pojazd) |
| GET | `/api/parking/aktywne` | Lista wszystkich aktywnych post\u0142oj\u00f3w | kontroler |

Przyk\u0142adowe \u017c\u0105danie:

```bash
curl -X POST http://localhost:8080/api/parking/rozpocznij \
  -H "Content-Type: application/json" \
  -H "X-Numer-Rejestracyjny: WA12345" \
  -d '{"numerRejestracyjny":"WA12345"}'

curl http://localhost:8080/api/parking/WA12345/kwota -H "X-Numer-Rejestracyjny: WA12345"
```

## Algorytmy

**Dop\u0142ata za baga\u017c** (`BagazService.oblicz`):
- gabaryty: suma wymiar\u00f3w X+Y+Z musi by\u0107 \u2264 limitu lotu, w przeciwnym razie doliczana jest op\u0142ata rycza\u0142towa,
- waga: ka\u017cdy kilogram powy\u017cej limitu bazowego mno\u017cony jest przez stawk\u0119 lotu za kg nadbaga\u017cu,
- suma do zap\u0142aty = dop\u0142ata za nadwag\u0119 + (ewentualna) op\u0142ata za gabaryty.

**Op\u0142ata za post\u00f3j** (`PostojService.obliczOplate`):
- pierwsza rozpocz\u0119ta godzina: 5 z\u0142,
- ka\u017cda kolejna rozpocz\u0119ta godzina: 4 z\u0142,
- je\u015bli post\u00f3j rozpocz\u0105\u0142 si\u0119 w weekend (sobota/niedziela) - ca\u0142a kwota jest o po\u0142ow\u0119 ta\u0144sza.

## Uwagi / za\u0142o\u017cenia upraszczaj\u0105ce

- Personel (pracownik lotniska, kontroler) jest zdefiniowany jako u\u017cytkownicy w pami\u0119ci (`SecurityConfig`) -
  w rzeczywistym systemie dane logowania trzymane by\u0142yby w bazie.
- Baza danych to H2 w pami\u0119ci (`ddl-auto: create-drop`) - dane resetuj\u0105 si\u0119 po restarcie; do produkcji
  wystarczy podmieni\u0107 `spring.datasource` na PostgreSQL/MySQL.
- Zni\u017cka weekendowa liczona jest wg dnia rozpocz\u0119cia post\u0142oju (uproszczenie, bez dzielenia
  op\u0142aty godzina-po-godzinie mi\u0119dzy dni robocze i weekend).
