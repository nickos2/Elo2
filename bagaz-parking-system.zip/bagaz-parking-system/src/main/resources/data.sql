-- Loty (baga\u017c podr\u0119czny: limit 8 kg, suma wymiar\u00f3w max 115 cm, 50 z\u0142/kg nadbaga\u017cu, 150 z\u0142 kara za gabaryty)
INSERT INTO lot (trasa, limit_wagi_kg, limit_suma_wymiarow_cm, stawka_za_kg_nadbagazu, oplata_za_przekroczone_gabaryty)
VALUES ('WAW-LHR', 8, 115, 50.00, 150.00);
INSERT INTO lot (trasa, limit_wagi_kg, limit_suma_wymiarow_cm, stawka_za_kg_nadbagazu, oplata_za_przekroczone_gabaryty)
VALUES ('KRK-FRA', 10, 118, 40.00, 120.00);

-- Miejsca parkingowe
INSERT INTO miejsce_parkingowe (strefa) VALUES ('A');
INSERT INTO miejsce_parkingowe (strefa) VALUES ('B');
INSERT INTO miejsce_parkingowe (strefa) VALUES ('VIP');
