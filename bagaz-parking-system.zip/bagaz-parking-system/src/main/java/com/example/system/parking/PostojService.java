package com.example.system.parking;

import com.example.system.parking.dto.PostojResponse;
import com.example.system.parking.dto.RozpocznijPostojRequest;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.DayOfWeek;
import java.time.Duration;
import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class PostojService {

    private static final BigDecimal STAWKA_PIERWSZA_GODZINA = BigDecimal.valueOf(5);
    private static final BigDecimal STAWKA_KOLEJNA_GODZINA = BigDecimal.valueOf(4);
    private static final BigDecimal ZNIZKA_WEEKEND = BigDecimal.valueOf(0.5);

    private final PostojRepository postojRepository;
    private final MiejsceParkingoweRepository miejsceParkingoweRepository;

    /**
     * Czysta logika naliczania op\u0142aty za post\u00f3j - \u0142atwa do testowania jednostkowego.
     *
     * Zasady:
     *  - pierwsza (rozpocz\u0119ta) godzina kosztuje 5 z\u0142,
     *  - ka\u017cda kolejna rozpocz\u0119ta godzina kosztuje 4 z\u0142,
     *  - je\u015bli post\u00f3j rozpocz\u0105\u0142 si\u0119 w weekend (sobota lub niedziela), ca\u0142a op\u0142ata jest o po\u0142ow\u0119 ta\u0144sza.
     */
    public BigDecimal obliczOplate(LocalDateTime czasWjazdu, LocalDateTime czasWyjazdu) {
        if (czasWyjazdu.isBefore(czasWjazdu)) {
            throw new IllegalArgumentException("Czas wyjazdu nie mo\u017ce by\u0107 wcze\u015bniejszy ni\u017c czas wjazdu.");
        }

        long rozpoczeteGodziny = obliczRozpoczeteGodziny(czasWjazdu, czasWyjazdu);
        if (rozpoczeteGodziny == 0) {
            return BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP);
        }

        BigDecimal kwota = STAWKA_PIERWSZA_GODZINA
                .add(STAWKA_KOLEJNA_GODZINA.multiply(BigDecimal.valueOf(rozpoczeteGodziny - 1)));

        if (jestWeekend(czasWjazdu)) {
            kwota = kwota.multiply(ZNIZKA_WEEKEND);
        }

        return kwota.setScale(2, RoundingMode.HALF_UP);
    }

    public long obliczRozpoczeteGodziny(LocalDateTime czasWjazdu, LocalDateTime czasWyjazdu) {
        Duration czasTrwania = Duration.between(czasWjazdu, czasWyjazdu);
        if (czasTrwania.isZero()) {
            return 0;
        }
        long sekundy = czasTrwania.getSeconds();
        return (long) Math.ceil(sekundy / 3600.0);
    }

    public boolean jestWeekend(LocalDateTime dataCzas) {
        DayOfWeek dzien = dataCzas.getDayOfWeek();
        return dzien == DayOfWeek.SATURDAY || dzien == DayOfWeek.SUNDAY;
    }

    // --- operacje na bazie danych ---

    public Postoj rozpocznijPostoj(RozpocznijPostojRequest request) {
        postojRepository.findFirstByNumerRejestracyjnyAndCzasWyjazduIsNull(request.getNumerRejestracyjny())
                .ifPresent(p -> {
                    throw new IllegalStateException("Pojazd " + request.getNumerRejestracyjny() + " ma ju\u017c aktywny post\u00f3j.");
                });

        MiejsceParkingowe miejsce = request.getMiejsceParkingoweId() != null
                ? miejsceParkingoweRepository.findById(request.getMiejsceParkingoweId()).orElse(null)
                : null;

        Postoj postoj = Postoj.builder()
                .numerRejestracyjny(request.getNumerRejestracyjny())
                .miejsceParkingowe(miejsce)
                .czasWjazdu(LocalDateTime.now())
                .build();

        return postojRepository.save(postoj);
    }

    public PostojResponse sprawdzKwote(String numerRejestracyjny) {
        Postoj postoj = postojRepository.findFirstByNumerRejestracyjnyAndCzasWyjazduIsNull(numerRejestracyjny)
                .orElseThrow(() -> new IllegalArgumentException("Brak aktywnego post\u0142oju dla pojazdu " + numerRejestracyjny));

        LocalDateTime teraz = LocalDateTime.now();
        BigDecimal kwota = obliczOplate(postoj.getCzasWjazdu(), teraz);

        return PostojResponse.builder()
                .numerRejestracyjny(numerRejestracyjny)
                .czasWjazdu(postoj.getCzasWjazdu())
                .czasWyjazdu(null)
                .aktywny(true)
                .weekend(jestWeekend(postoj.getCzasWjazdu()))
                .rozpoczeteGodziny(obliczRozpoczeteGodziny(postoj.getCzasWjazdu(), teraz))
                .kwotaDoZaplaty(kwota)
                .build();
    }

    public PostojResponse zakonczPostoj(String numerRejestracyjny) {
        Postoj postoj = postojRepository.findFirstByNumerRejestracyjnyAndCzasWyjazduIsNull(numerRejestracyjny)
                .orElseThrow(() -> new IllegalArgumentException("Brak aktywnego post\u0142oju dla pojazdu " + numerRejestracyjny));

        LocalDateTime teraz = LocalDateTime.now();
        BigDecimal kwota = obliczOplate(postoj.getCzasWjazdu(), teraz);

        postoj.setCzasWyjazdu(teraz);
        postoj.setKwotaZaplacona(kwota);
        postojRepository.save(postoj);

        return PostojResponse.builder()
                .numerRejestracyjny(numerRejestracyjny)
                .czasWjazdu(postoj.getCzasWjazdu())
                .czasWyjazdu(teraz)
                .aktywny(false)
                .weekend(jestWeekend(postoj.getCzasWjazdu()))
                .rozpoczeteGodziny(obliczRozpoczeteGodziny(postoj.getCzasWjazdu(), teraz))
                .kwotaDoZaplaty(kwota)
                .build();
    }
}
