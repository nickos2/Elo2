package com.example.system.baggage.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class BagazRequest {

    @NotBlank
    private String numerRezerwacji;

    @NotNull
    private Long lotId;

    @Positive
    private double wagaKg;

    @Positive
    private double wymiarXCm;

    @Positive
    private double wymiarYCm;

    @Positive
    private double wymiarZCm;
}
