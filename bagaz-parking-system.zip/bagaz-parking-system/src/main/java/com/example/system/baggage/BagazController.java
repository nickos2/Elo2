package com.example.system.baggage;

import com.example.system.baggage.dto.BagazRequest;
import com.example.system.baggage.dto.BagazResponse;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Endpointy modu\u0142u baga\u017cowego.
 *
 * Bezpiecze\u0144stwo:
 *  - Klient uwierzytelnia si\u0119 nag\u0142\u00f3wkiem "X-Numer-Rezerwacji" (patrz ReservationAuthFilter) -
 *    mo\u017ce walidowa\u0107 wy\u0142\u0105cznie w\u0142asny baga\u017c (numer rezerwacji z nag\u0142\u00f3wka musi zgadza\u0107 si\u0119
 *    z numerem w body).
 *  - Pracownik lotniska loguje si\u0119 standardowo (HTTP Basic, rola PRACOWNIK_LOTNISKA) i widzi
 *    wszystkie baga\u017ce dla danego lotu.
 */
@RestController
@RequestMapping("/api/bagaz")
@RequiredArgsConstructor
@Tag(name = "Baga\u017c", description = "Walidacja gabaryt\u00f3w i dop\u0142aty za nadbaga\u017c")
public class BagazController {

    private final BagazService bagazService;
    private final BagazRepository bagazRepository;

    @Operation(summary = "Waliduje baga\u017c i zwraca sum\u0119 dop\u0142aty do zap\u0142aty")
    @PostMapping("/waliduj")
    public ResponseEntity<BagazResponse> waliduj(@Valid @RequestBody BagazRequest request,
                                                  Authentication authentication) {
        if (!maUprawnienieDoRezerwacji(authentication, request.getNumerRezerwacji())) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(bagazService.walidujIZapisz(request));
    }

    @Operation(summary = "Lista wszystkich baga\u017cy dla danego lotu (tylko pracownik lotniska)")
    @PreAuthorize("hasRole('PRACOWNIK_LOTNISKA')")
    @GetMapping("/lot/{lotId}")
    public ResponseEntity<List<Bagaz>> bagazeDlaLotu(@PathVariable Long lotId) {
        return ResponseEntity.ok(bagazRepository.findByLot_Id(lotId));
    }

    private boolean maUprawnienieDoRezerwacji(Authentication authentication, String numerRezerwacji) {
        if (authentication == null) {
            return false;
        }
        boolean jestPracownikiem = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_PRACOWNIK_LOTNISKA"));
        if (jestPracownikiem) {
            return true;
        }
        // klient - identyfikowany numerem rezerwacji przekazanym w nag\u0142\u00f3wku (patrz ReservationAuthFilter)
        return numerRezerwacji != null && numerRezerwacji.equals(authentication.getName());
    }
}
