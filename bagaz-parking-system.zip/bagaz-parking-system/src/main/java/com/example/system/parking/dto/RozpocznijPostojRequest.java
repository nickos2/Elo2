package com.example.system.parking.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class RozpocznijPostojRequest {

    @NotBlank
    private String numerRejestracyjny;

    private Long miejsceParkingoweId;
}
