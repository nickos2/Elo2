package com.example.system.config;

import com.example.system.security.TozsamosciKlientaFilter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.provisioning.InMemoryUserDetailsManager;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

@Configuration
@EnableMethodSecurity
public class SecurityConfig {

    @Bean
    public PasswordEncoder passwordEncoder() {
        return new BCryptPasswordEncoder();
    }

    /**
     * Konta demonstracyjne dla personelu. W realnym systemie dane logowania
     * pochodzi\u0142yby z bazy danych (np. tabeli pracownicy).
     */
    @Bean
    public UserDetailsService userDetailsService(PasswordEncoder encoder) {
        return new InMemoryUserDetailsManager(
                User.withUsername("pracownik")
                        .password(encoder.encode("pracownik123"))
                        .roles("PRACOWNIK_LOTNISKA")
                        .build(),
                User.withUsername("kontroler")
                        .password(encoder.encode("kontroler123"))
                        .roles("KONTROLER")
                        .build()
        );
    }

    @Bean
    public SecurityFilterChain filterChain(HttpSecurity http) throws Exception {
        http
                .csrf(csrf -> csrf.disable())
                .headers(headers -> headers.frameOptions(frame -> frame.disable()))
                .authorizeHttpRequests(auth -> auth
                        .requestMatchers("/swagger-ui/**", "/v3/api-docs/**", "/", "/index.html",
                                "/checkin.html", "/parking.html", "/*.css", "/*.js", "/h2-console/**").permitAll()
                        .anyRequest().authenticated())
                .httpBasic(basic -> {})
                .addFilterBefore(new TozsamosciKlientaFilter(), UsernamePasswordAuthenticationFilter.class);

        return http.build();
    }
}
