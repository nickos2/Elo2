package com.example.system.parking;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "miejsce_parkingowe")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class MiejsceParkingowe {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Np. "A", "B", "VIP" */
    @Column(nullable = false)
    private String strefa;
}
