package com.example.system.parking.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Getter
@Builder
@AllArgsConstructor
public class PostojResponse {
    private String numerRejestracyjny;
    private LocalDateTime czasWjazdu;
    private LocalDateTime czasWyjazdu;
    private boolean aktywny;
    private boolean weekend;
    private long rozpoczeteGodziny;
    private BigDecimal kwotaDoZaplaty;
}
