package com.example.system.baggage;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

/**
 * Lot (po\u0142\u0105czenie lotnicze) wraz z limitami baga\u017cu podr\u0119cznego.
 */
@Entity
@Table(name = "lot")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Lot {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Np. "WAW-LHR" */
    @Column(nullable = false)
    private String trasa;

    /** Bazowy, bezp\u0142atny limit wagi baga\u017cu podr\u0119cznego w kg. */
    @Column(nullable = false)
    private double limitWagiKg;

    /** Maksymalna dopuszczalna suma wymiar\u00f3w X+Y+Z w cm (standard IATA dla baga\u017cu podr\u0119cznego). */
    @Column(nullable = false)
    private double limitSumaWymiarowCm;

    /** Stawka za ka\u017cdy kilogram nadbaga\u017cu (z\u0142/kg). */
    @Column(nullable = false)
    private BigDecimal stawkaZaKgNadbagazu;

    /** Op\u0142ata ryczartowa doliczana, gdy baga\u017c przekracza dopuszczalne gabaryty. */
    @Column(nullable = false)
    private BigDecimal oplataZaPrzekroczoneGabaryty;
}
