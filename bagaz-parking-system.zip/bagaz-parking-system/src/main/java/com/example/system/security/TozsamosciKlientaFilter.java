package com.example.system.security;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;
import java.util.List;

/**
 * Klient nie posiada tradycyjnego loginu/has\u0142a - jego to\u017csamo\u015bci\u0105 jest numer
 * rezerwacji (modu\u0142 baga\u017cowy) lub numer rejestracyjny pojazdu (modu\u0142 parkingowy),
 * przekazywany w nag\u0142\u00f3wku \u017c\u0105dania. Filtr ustawia Authentication z rol\u0105 ROLE_KLIENT,
 * je\u015bli u\u017cytkownik nie zosta\u0142 ju\u017c uwierzytelniony w inny spos\u00f3b (np. HTTP Basic
 * dla pracownika/kontrolera).
 */
public class TozsamosciKlientaFilter extends OncePerRequestFilter {

    public static final String NAGLOWEK_REZERWACJA = "X-Numer-Rezerwacji";
    public static final String NAGLOWEK_REJESTRACJA = "X-Numer-Rejestracyjny";

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
            throws ServletException, IOException {

        if (SecurityContextHolder.getContext().getAuthentication() == null) {
            String identyfikator = request.getHeader(NAGLOWEK_REZERWACJA);
            if (identyfikator == null) {
                identyfikator = request.getHeader(NAGLOWEK_REJESTRACJA);
            }

            if (identyfikator != null && !identyfikator.isBlank()) {
                Authentication authentication = new UsernamePasswordAuthenticationToken(
                        identyfikator, null, List.of(new SimpleGrantedAuthority("ROLE_KLIENT")));
                SecurityContextHolder.getContext().setAuthentication(authentication);
            }
        }

        chain.doFilter(request, response);
    }
}
