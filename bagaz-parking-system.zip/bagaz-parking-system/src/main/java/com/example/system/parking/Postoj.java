package com.example.system.parking;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;
import java.time.LocalDateTime;

@Entity
@Table(name = "postoj")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Postoj {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false)
    private String numerRejestracyjny;

    @ManyToOne
    @JoinColumn(name = "miejsce_parkingowe_id")
    private MiejsceParkingowe miejsceParkingowe;

    @Column(nullable = false)
    private LocalDateTime czasWjazdu;

    /** null dop\u00f3ki post\u00f3j trwa */
    private LocalDateTime czasWyjazdu;

    /** Kwota naliczona w momencie zako\u0144czenia post\u0142oju (null je\u015bli post\u00f3j trwa). */
    private BigDecimal kwotaZaplacona;

    public boolean isAktywny() {
        return czasWyjazdu == null;
    }
}
