package com.example.system.baggage;

import jakarta.persistence.*;
import lombok.*;

import java.math.BigDecimal;

@Entity
@Table(name = "bagaz")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Bagaz {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable = false, unique = true)
    private String numerRezerwacji;

    @ManyToOne(optional = false)
    @JoinColumn(name = "lot_id")
    private Lot lot;

    @Column(nullable = false)
    private double wagaKg;

    @Column(nullable = false)
    private double wymiarXCm;

    @Column(nullable = false)
    private double wymiarYCm;

    @Column(nullable = false)
    private double wymiarZCm;

    /** Wynik ostatniej walidacji - zapisywany po przeliczeniu, do wgl\u0105du dla pracownika lotniska. */
    private boolean mieisciSieWGabarytach;

    private BigDecimal doplataDoZaplaty;
}
