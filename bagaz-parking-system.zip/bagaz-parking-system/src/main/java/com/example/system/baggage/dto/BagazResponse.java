package com.example.system.baggage.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;

import java.math.BigDecimal;

@Getter
@Builder
@AllArgsConstructor
public class BagazResponse {
    private String numerRezerwacji;
    private boolean mieisciSieWGabarytach;
    private double sumaWymiarowCm;
    private double limitSumaWymiarowCm;
    private double nadwagaKg;
    private BigDecimal doplataZaNadwage;
    private BigDecimal oplataZaGabaryty;
    private BigDecimal sumaDoZaplaty;
    private String komunikat;
}
