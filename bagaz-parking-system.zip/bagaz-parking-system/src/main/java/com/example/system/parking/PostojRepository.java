package com.example.system.parking;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface PostojRepository extends JpaRepository<Postoj, Long> {
    Optional<Postoj> findFirstByNumerRejestracyjnyAndCzasWyjazduIsNull(String numerRejestracyjny);
    List<Postoj> findByCzasWyjazduIsNull();
}
