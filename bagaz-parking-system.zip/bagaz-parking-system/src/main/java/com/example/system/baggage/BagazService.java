package com.example.system.baggage;

import com.example.system.baggage.dto.BagazRequest;
import com.example.system.baggage.dto.BagazResponse;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.math.RoundingMode;

@Service
@RequiredArgsConstructor
public class BagazService {

    private final LotRepository lotRepository;
    private final BagazRepository bagazRepository;

    /**
     * Czysta logika biznesowa - \u0142atwa do testowania jednostkowego bez kontekstu Springa.
     * Zwraca wynik walidacji gabaryt\u00f3w oraz wyliczon\u0105 dop\u0142at\u0119 za nadbaga\u017c.
     */
    public BagazResponse oblicz(Lot lot, String numerRezerwacji, double wagaKg,
                                 double x, double y, double z) {

        double sumaWymiarow = x + y + z;
        boolean mieisciSieWGabarytach = sumaWymiarow <= lot.getLimitSumaWymiarowCm();

        double nadwagaKg = Math.max(0.0, wagaKg - lot.getLimitWagiKg());
        BigDecimal doplataZaNadwage = BigDecimal.valueOf(nadwagaKg)
                .multiply(lot.getStawkaZaKgNadbagazu())
                .setScale(2, RoundingMode.HALF_UP);

        BigDecimal oplataZaGabaryty = mieisciSieWGabarytach
                ? BigDecimal.ZERO.setScale(2, RoundingMode.HALF_UP)
                : lot.getOplataZaPrzekroczoneGabaryty().setScale(2, RoundingMode.HALF_UP);

        BigDecimal sumaDoZaplaty = doplataZaNadwage.add(oplataZaGabaryty);

        String komunikat = mieisciSieWGabarytach
                ? "Baga\u017c mie\u015bci si\u0119 w dopuszczalnych gabarytach."
                : "Baga\u017c przekracza dopuszczaln\u0105 sum\u0119 wymiar\u00f3w (" + lot.getLimitSumaWymiarowCm() + " cm).";

        return BagazResponse.builder()
                .numerRezerwacji(numerRezerwacji)
                .mieisciSieWGabarytach(mieisciSieWGabarytach)
                .sumaWymiarowCm(sumaWymiarow)
                .limitSumaWymiarowCm(lot.getLimitSumaWymiarowCm())
                .nadwagaKg(nadwagaKg)
                .doplataZaNadwage(doplataZaNadwage)
                .oplataZaGabaryty(oplataZaGabaryty)
                .sumaDoZaplaty(sumaDoZaplaty)
                .komunikat(komunikat)
                .build();
    }

    /** Waliduje zg\u0142oszenie, zapisuje wynik w bazie i zwraca odpowied\u017a. */
    public BagazResponse walidujIZapisz(BagazRequest request) {
        Lot lot = lotRepository.findById(request.getLotId())
                .orElseThrow(() -> new IllegalArgumentException("Nie znaleziono lotu o id " + request.getLotId()));

        BagazResponse response = oblicz(lot, request.getNumerRezerwacji(), request.getWagaKg(),
                request.getWymiarXCm(), request.getWymiarYCm(), request.getWymiarZCm());

        Bagaz bagaz = bagazRepository.findByNumerRezerwacji(request.getNumerRezerwacji())
                .orElse(Bagaz.builder().numerRezerwacji(request.getNumerRezerwacji()).build());

        bagaz.setLot(lot);
        bagaz.setWagaKg(request.getWagaKg());
        bagaz.setWymiarXCm(request.getWymiarXCm());
        bagaz.setWymiarYCm(request.getWymiarYCm());
        bagaz.setWymiarZCm(request.getWymiarZCm());
        bagaz.setMieisciSieWGabarytach(response.isMieisciSieWGabarytach());
        bagaz.setDoplataDoZaplaty(response.getSumaDoZaplaty());
        bagazRepository.save(bagaz);

        return response;
    }
}
