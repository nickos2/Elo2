package com.example.system.baggage;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface BagazRepository extends JpaRepository<Bagaz, Long> {
    Optional<Bagaz> findByNumerRezerwacji(String numerRezerwacji);
    List<Bagaz> findByLot_Id(Long lotId);
}
