package com.example.system.parking;

import org.springframework.data.jpa.repository.JpaRepository;

public interface MiejsceParkingoweRepository extends JpaRepository<MiejsceParkingowe, Long> {
}
