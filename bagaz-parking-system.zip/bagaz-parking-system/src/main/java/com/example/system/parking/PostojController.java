package com.example.system.parking;

import com.example.system.parking.dto.PostojResponse;
import com.example.system.parking.dto.RozpocznijPostojRequest;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Bezpiecze\u0144stwo:
 *  - Klient uwierzytelniony nag\u0142\u00f3wkiem "X-Numer-Rejestracyjny" widzi/obs\u0142uguje wy\u0142\u0105cznie
 *    w\u0142asny pojazd (numer z nag\u0142\u00f3wka musi zgadza\u0107 si\u0119 z numerem w \u017c\u0105daniu).
 *  - Kontroler loguje si\u0119 standardowo (HTTP Basic, rola KONTROLER) i widzi list\u0119 wszystkich
 *    aktywnych post\u0142oj\u00f3w.
 */
@RestController
@RequestMapping("/api/parking")
@RequiredArgsConstructor
@Tag(name = "Parking", description = "Kalkulator op\u0142at za post\u00f3j")
public class PostojController {

    private final PostojService postojService;
    private final PostojRepository postojRepository;

    @Operation(summary = "Rozpoczyna post\u00f3j dla podanego numeru rejestracyjnego")
    @PostMapping("/rozpocznij")
    public ResponseEntity<Postoj> rozpocznij(@Valid @RequestBody RozpocznijPostojRequest request,
                                              Authentication authentication) {
        if (!maUprawnienieDoPojazdu(authentication, request.getNumerRejestracyjny())) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(postojService.rozpocznijPostoj(request));
    }

    @Operation(summary = "Zwraca bie\u017c\u0105c\u0105 kwot\u0119 do zap\u0142aty dla danego numeru rejestracyjnego")
    @GetMapping("/{numerRejestracyjny}/kwota")
    public ResponseEntity<PostojResponse> kwota(@PathVariable String numerRejestracyjny,
                                                 Authentication authentication) {
        if (!maUprawnienieDoPojazdu(authentication, numerRejestracyjny)) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(postojService.sprawdzKwote(numerRejestracyjny));
    }

    @Operation(summary = "Ko\u0144czy post\u00f3j i nalicza op\u0142at\u0119 ko\u0144cow\u0105")
    @PostMapping("/{numerRejestracyjny}/zakoncz")
    public ResponseEntity<PostojResponse> zakoncz(@PathVariable String numerRejestracyjny,
                                                   Authentication authentication) {
        if (!maUprawnienieDoPojazdu(authentication, numerRejestracyjny)) {
            return ResponseEntity.status(403).build();
        }
        return ResponseEntity.ok(postojService.zakonczPostoj(numerRejestracyjny));
    }

    @Operation(summary = "Lista wszystkich aktywnych post\u0142oj\u00f3w (tylko kontroler)")
    @PreAuthorize("hasRole('KONTROLER')")
    @GetMapping("/aktywne")
    public ResponseEntity<List<Postoj>> aktywne() {
        return ResponseEntity.ok(postojRepository.findByCzasWyjazduIsNull());
    }

    private boolean maUprawnienieDoPojazdu(Authentication authentication, String numerRejestracyjny) {
        if (authentication == null) {
            return false;
        }
        boolean jestKontrolerem = authentication.getAuthorities().stream()
                .anyMatch(a -> a.getAuthority().equals("ROLE_KONTROLER"));
        if (jestKontrolerem) {
            return true;
        }
        return numerRejestracyjny != null && numerRejestracyjny.equals(authentication.getName());
    }
}
