package com.example.system.parking;

import org.junit.jupiter.api.Test;

import java.math.BigDecimal;
import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

class PostojServiceTest {

    // repozytoria nie s\u0105 potrzebne do testowania czystej metody obliczOplate()
    private final PostojService postojService = new PostojService(null, null);

    @Test
    void postojKrotszyNizGodzine_liczonyJakoJednaRozpocetaGodzina() {
        // poniedzialek 10:00 - 10:30 -> 1 rozpoczeta godzina -> 5 zl
        LocalDateTime wjazd = LocalDateTime.of(2026, 7, 6, 10, 0); // poniedzialek
        LocalDateTime wyjazd = wjazd.plusMinutes(30);

        BigDecimal kwota = postojService.obliczOplate(wjazd, wyjazd);

        assertEquals(new BigDecimal("5.00"), kwota);
    }

    @Test
    void postojDwieIPolGodziny_pierwszaGodzinaPlusDwieKolejne() {
        // 2h 15 min -> 3 rozpoczete godziny -> 5 + 4 + 4 = 13 zl
        LocalDateTime wjazd = LocalDateTime.of(2026, 7, 6, 9, 0); // poniedzialek
        LocalDateTime wyjazd = wjazd.plusMinutes(135);

        BigDecimal kwota = postojService.obliczOplate(wjazd, wyjazd);

        assertEquals(new BigDecimal("13.00"), kwota);
    }

    @Test
    void postojWSobote_polowaCeny() {
        // sobota, 2h -> normalnie 5 + 4 = 9 zl, w weekend -> 4.50 zl
        LocalDateTime wjazd = LocalDateTime.of(2026, 7, 4, 12, 0); // sobota
        LocalDateTime wyjazd = wjazd.plusHours(2);

        BigDecimal kwota = postojService.obliczOplate(wjazd, wyjazd);

        assertEquals(new BigDecimal("4.50"), kwota);
    }

    @Test
    void postojWNiedziele_polowaCeny() {
        LocalDateTime wjazd = LocalDateTime.of(2026, 7, 5, 8, 0); // niedziela
        LocalDateTime wyjazd = wjazd.plusHours(3); // 5+4+4=13 -> /2 = 6.50

        BigDecimal kwota = postojService.obliczOplate(wjazd, wyjazd);

        assertEquals(new BigDecimal("6.50"), kwota);
    }

    @Test
    void postojZerowejDlugosci_brakOplaty() {
        LocalDateTime wjazd = LocalDateTime.of(2026, 7, 6, 9, 0);

        BigDecimal kwota = postojService.obliczOplate(wjazd, wjazd);

        assertEquals(new BigDecimal("0.00"), kwota);
    }

    @Test
    void czasWyjazduPrzedWjazdem_rzucaWyjatek() {
        LocalDateTime wjazd = LocalDateTime.of(2026, 7, 6, 9, 0);
        LocalDateTime wyjazd = wjazd.minusMinutes(1);

        assertThrows(IllegalArgumentException.class, () -> postojService.obliczOplate(wjazd, wyjazd));
    }

    @Test
    void rozpoczetaGodzinaLiczySieWCalosci() {
        // dokladnie 60 min -> 1 godzina, 61 min -> 2 rozpoczete godziny
        LocalDateTime wjazd = LocalDateTime.of(2026, 7, 6, 9, 0);
        assertEquals(1, postojService.obliczRozpoczeteGodziny(wjazd, wjazd.plusMinutes(60)));
        assertEquals(2, postojService.obliczRozpoczeteGodziny(wjazd, wjazd.plusMinutes(61)));
    }
}
