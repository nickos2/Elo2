package com.example.system.baggage;

import com.example.system.baggage.dto.BagazResponse;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

class BagazServiceTest {

    private BagazService bagazService;
    private Lot lot;

    @BeforeEach
    void setUp() {
        // repozytoria nie s\u0105 potrzebne do testowania czystej metody oblicz()
        bagazService = new BagazService(null, null);
        lot = Lot.builder()
                .id(1L)
                .trasa("WAW-LHR")
                .limitWagiKg(8.0)
                .limitSumaWymiarowCm(115.0)
                .stawkaZaKgNadbagazu(BigDecimal.valueOf(50))
                .oplataZaPrzekroczoneGabaryty(BigDecimal.valueOf(150))
                .build();
    }

    @Test
    void bagazWGranicachLimitow_brakDoplaty() {
        BagazResponse wynik = bagazService.oblicz(lot, "REZ-1", 8.0, 40, 30, 20);

        assertTrue(wynik.isMieisciSieWGabarytach());
        assertEquals(0, wynik.getNadwagaKg());
        assertEquals(new BigDecimal("0.00"), wynik.getDoplataZaNadwage());
        assertEquals(new BigDecimal("0.00"), wynik.getOplataZaGabaryty());
        assertEquals(new BigDecimal("0.00"), wynik.getSumaDoZaplaty());
    }

    @Test
    void bagazZaCiezki_naliczaDoplateZaKazdyKilogram() {
        // 8 kg limitu, waga 10.5 kg -> 2.5 kg nadwagi * 50 zl/kg = 125.00 zl
        BagazResponse wynik = bagazService.oblicz(lot, "REZ-2", 10.5, 40, 30, 20);

        assertTrue(wynik.isMieisciSieWGabarytach());
        assertEquals(2.5, wynik.getNadwagaKg(), 0.0001);
        assertEquals(new BigDecimal("125.00"), wynik.getDoplataZaNadwage());
        assertEquals(new BigDecimal("125.00"), wynik.getSumaDoZaplaty());
    }

    @Test
    void bagazPrzekraczaGabaryty_naliczaOplateRyczaltowa() {
        // suma wymiarow 60+45+25=130 > 115 -> przekroczone gabaryty
        BagazResponse wynik = bagazService.oblicz(lot, "REZ-3", 8.0, 60, 45, 25);

        assertFalse(wynik.isMieisciSieWGabarytach());
        assertEquals(130.0, wynik.getSumaWymiarowCm(), 0.0001);
        assertEquals(new BigDecimal("150.00"), wynik.getOplataZaGabaryty());
        assertEquals(new BigDecimal("150.00"), wynik.getSumaDoZaplaty());
    }

    @Test
    void bagazPrzekraczaGabarytyIWage_sumujeObieOplaty() {
        BagazResponse wynik = bagazService.oblicz(lot, "REZ-4", 12.0, 70, 50, 30);

        assertFalse(wynik.isMieisciSieWGabarytach());
        // nadwaga: 4 kg * 50 = 200.00; gabaryty: 150.00; suma: 350.00
        assertEquals(new BigDecimal("200.00"), wynik.getDoplataZaNadwage());
        assertEquals(new BigDecimal("150.00"), wynik.getOplataZaGabaryty());
        assertEquals(new BigDecimal("350.00"), wynik.getSumaDoZaplaty());
    }

    @Test
    void bagazDokladnieNaLimicieWymiarow_uznanyZaMieszczacySie() {
        // suma dokladnie rowna limitowi (115 cm) powinna byc zaakceptowana (<=)
        BagazResponse wynik = bagazService.oblicz(lot, "REZ-5", 8.0, 55, 40, 20);

        assertTrue(wynik.isMieisciSieWGabarytach());
    }
}
